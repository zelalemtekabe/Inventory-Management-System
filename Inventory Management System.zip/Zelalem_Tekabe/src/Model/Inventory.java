/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author zelal
 */
public class Inventory {

    public Inventory() {
    }

    ;
    private static ObservableList<Part> allParts = FXCollections.observableArrayList();
    private static ObservableList<Product> allProducts = FXCollections.observableArrayList();
    private static int partIDCount = 0;
    private static int productIDCount = 0;

    public static void addPart(Part newPart) {
        allParts.add(newPart);
    }

    ;
    
    public static void addProduct(Product newProduct) {
        allProducts.add(newProduct);
    }

    ;
    
    public static Part lookupPart(int partId) {
        for (Part prt : allParts) {
            if (prt.getId() == partId) {
                return prt;
            }

        }
        return null;
    }

    public static Product lookupProduct(int productId) {
        for (Product prdct : allProducts) {
            if (prdct.getId() == productId) {
                return prdct;
            }

        }
        return null;
    }

    ;
    
      public static int lookupPart(String srchString) {
        boolean isFound = false;
        int index = 0;
        if (isInteger(srchString)) {
            for (int i = 0; i < allParts.size(); i++) {
                if (Integer.parseInt(srchString) == allParts.get(i).getId()) {
                    index = i;
                    isFound = true;
                }
            }
        } else {
            for (int i = 0; i < allParts.size(); i++) {
                if (srchString.equals(allParts.get(i).getName())) {
                    index = i;
                    isFound = true;
                }
            }
        }
        if (isFound = true) {
            return index;
        } else {
            System.out.println("No parts found.");
            return -1;
        }
    }

    public static int lookupProduct(String srchString) {
        boolean isFound = false;
        int index = 0;
        if (isInteger(srchString)) {
            for (int i = 0; i < allProducts.size(); i++) {
                if (Integer.parseInt(srchString) == allProducts.get(i).getId()) {
                    index = i;
                    isFound = true;
                }
            }
        } else {
            for (int i = 0; i < allProducts.size(); i++) {
                if (srchString.equals(allProducts.get(i).getName())) {
                    index = i;
                    isFound = true;
                }
            }
        }
        if (isFound = true) {
            return index;
        } else {
            System.out.println("No parts found.");
            return -1;
        }
    }

    public static boolean isInteger(String input) {
        try {
            Integer.parseInt(input);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    ;
    
    public static void updatePart(int index, Part selectedPart) {
        allParts.set(index, selectedPart);
             
    }

    ;
    
    public static void updateProduct(int index, Product newProduct) {
        allProducts.set(index, newProduct);

    }

    ;
     //delete part
    public static boolean deletePart(Part selectedPart) {
        for (Part partDel : allParts) {
            if (partDel.equals(selectedPart)) {
                allParts.remove(partDel);
                return true;
            }
        }
        return false;
    }

    ;
    
    //delete product
    public static boolean deleteProduct(Product selectedProduct) {
        for (Product productDel : allProducts) {
            if (productDel.equals(selectedProduct)) {
                allProducts.remove(productDel);
                return true;
            }
        }
        return false;
    }

    ;
    
    public static ObservableList<Part> getAllParts() {
        return allParts;
    }

    public static ObservableList<Product> getAllProducts() {
        return allProducts;
    }

    //part ID generation
    public static int partsId() {
        partIDCount++;
        return partIDCount;
    }

    public static int productsId() {
        productIDCount++;
        return productIDCount;
    }

}
