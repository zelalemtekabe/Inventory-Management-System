/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

/**
 *
 * @author zelal
 */
public class Product {

    public  ObservableList<Part> associatedParts = FXCollections.observableArrayList();
    public  ObservableList<Product> associatedProducts = FXCollections.observableArrayList();
    private int id;
    private String name;
    private double price;
    private int stock;
    private int min;
    private int max;

    public Product() {

    }

    ;

    public void setId(int pId) {
        this.id = pId;

    }

    public void setName(String name) {
        this.name = name;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public void setMin(int min) {
        this.min = min;
    }

    public void setMax(int max) {
        this.max = max;
    }

    //getters 
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public double getPrice() {
        return price;
    }

    public void setAssociatedParts(ObservableList<Part> associatedParts) {
        this.associatedParts = associatedParts;
    }

    public ObservableList<Part> getAssociatedParts() {
        return associatedParts;
    }

    public int getStock() {
        return stock;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public void addAssociatedPart(Part part) {
        this.associatedParts.add(part);
        
    }

    ;
    
    public boolean deleteAssociatedPart(Part selectedAspart) {
        return false;
    }

    ;
    
    public ObservableList<Part> getAllAssociatedParts() {
       return null;
    }
;

}
