package Main;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author zelal
 */
public class Zelalem_Tekabe extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
       
        try{
        Parent root = FXMLLoader.load(getClass().getResource("/View_Controller/Main Screen.fxml"));
        
        stage.setResizable(false);
         
        Scene scene = new Scene(root);
        stage.setTitle("Inventory Management System");
        
        stage.setScene(scene);
        stage.show();
    }
        catch (IOException ex)
        {
        Logger.getLogger(Zelalem_Tekabe.class.getName()).log(Level.SEVERE,null, ex);
        }
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
    
    
}
