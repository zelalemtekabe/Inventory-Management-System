/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.InhousePart;
import Model.Inventory;
import Model.Part;
import static Model.Inventory.getAllParts;
import Model.OutsourcedPart;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import static View_Controller.MainScreenController.partsToModifyIndex;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableView;
import javafx.stage.Modality;

/**
 * FXML Controller class
 *
 * @author zelal
 */
public class ModifyPartController implements Initializable {

    private ToggleGroup rbToggleGp;

    @FXML
    private RadioButton inHouseModify;
    @FXML
    private RadioButton outSourcedModify;
    @FXML
    private Text companyNameOrIDModify;
    @FXML
    private TextField AddPart_ID;
    @FXML
    private TextField AddPart_Name;
    @FXML
    private TextField AddPart_Inventory;
    @FXML
    private TextField AddPart_PriceCost;
    @FXML
    private TextField AddPart_Max;
    @FXML
    private TextField AddPart_Min;
    @FXML
    private TextField AddPart_CompanyName;
    @FXML
    private TableView<Part> modPartTableView;

    private boolean isInhouse = true;

    @FXML
    private Button AddPart_Save;
    @FXML
    private Button AddPart_Cancel;

    @FXML
    private InhousePart partToModify;

    private final int prtIndex = partsToModifyIndex();
    private int partId;

    private static Part modifyPart;
    private static int modifyPartIndex;

    @FXML
    public void rbInHouseSelected(ActionEvent event) {
        isInhouse = true;
        inHouseModify.setSelected(true);
        outSourcedModify.setSelected(false);
        companyNameOrIDModify.setText("Machine ID :");

    }

    @FXML
    public void rbInOutsourcedSelected(ActionEvent event) {
        isInhouse = false;

        outSourcedModify.setSelected(true);
        inHouseModify.setSelected(false);
        companyNameOrIDModify.setText("Company Name :");

    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Part prt = getAllParts().get(prtIndex);

        if (prt instanceof InhousePart) {

            isInhouse = true;

            InhousePart iPart = (InhousePart) prt;

            partId = getAllParts().get(prtIndex).getId();
            AddPart_ID.setText(Integer.toString(partId));
            AddPart_Name.setText(iPart.getName());
            AddPart_Inventory.setText(Integer.toString(iPart.getStock()));
            AddPart_PriceCost.setText(Double.toString(iPart.getPrice()));
            AddPart_Max.setText(Integer.toString(iPart.getMax()));
            AddPart_Min.setText(Integer.toString(iPart.getMin()));

            inHouseModify.setSelected(true);
            //AddPart_CompanyName.setText(Integer.toString(((InhousePart) iPart).getMachineId()));
            AddPart_CompanyName.setText(Integer.toString(iPart.getMachineId()));
            companyNameOrIDModify.setText("Machine ID :");
        }

        if (prt instanceof OutsourcedPart) {
            isInhouse = false;
            OutsourcedPart oPart = (OutsourcedPart) prt;

            partId = getAllParts().get(prtIndex).getId();
            AddPart_ID.setText(Integer.toString(partId));
            AddPart_Name.setText(oPart.getName());
            AddPart_Inventory.setText(Integer.toString(oPart.getStock()));
            AddPart_PriceCost.setText(Double.toString(oPart.getPrice()));
            AddPart_Max.setText(Integer.toString(oPart.getMax()));
            AddPart_Min.setText(Integer.toString(oPart.getMin()));

            outSourcedModify.setSelected(true);
            AddPart_CompanyName.setText(oPart.getCompanyName());
            // AddPart_CompanyName.setText(((OutsourcedPart) oPart).getCompanyName());
            companyNameOrIDModify.setText("Company Name :");

        }

    }

    @FXML
    private void saveModifyPart(ActionEvent event) {
        if (AddPart_Name.getText().equals("") || AddPart_Name.getText() == null
                || AddPart_Inventory.getText().equals("") || AddPart_Inventory.getText() == null
                || AddPart_PriceCost.getText().equals("") || AddPart_PriceCost.getText() == null
                || AddPart_Min.getText().equals("") || AddPart_Min.getText() == null
                || AddPart_Max.getText().equals("") || AddPart_Max.getText() == null) {
            Alert adError = new Alert(Alert.AlertType.ERROR);
            adError.setContentText("One or more fields have an error.");
            adError.setHeaderText("Please check your inputs!");
            adError.setTitle("Error");
            adError.showAndWait();
        } else {

            try {
                String partName = AddPart_Name.getText();
                int partInventory = Integer.parseInt(AddPart_Inventory.getText());
                Double partPrice = Double.parseDouble(AddPart_PriceCost.getText());
                int partMin = Integer.parseInt(AddPart_Min.getText());
                int partMax = Integer.parseInt(AddPart_Max.getText());

                //Part updatedPart = getAllParts().get(prtIndex);
                //if (updatedPart instanceof InhousePart) {
                if (isInhouse == true) {

                    // InhousePart inPart = (InhousePart) updatedPart;
                    InhousePart inPart = new InhousePart();

                    rbInHouseSelected(event);

                    //InhousePart inPart = (InhousePart) updatedPart;
                    inPart.setId(Integer.parseInt(AddPart_ID.getText()));
                    inPart.setName(partName);
                    inPart.setStock(partInventory);
                    inPart.setPrice(partPrice);
                    inPart.setMin(partMin);
                    inPart.setMax(partMax);

                    inPart.setMachineId(Integer.parseInt(AddPart_CompanyName.getText()));

                    Inventory.updatePart(prtIndex, inPart);

                } else if (isInhouse == false) {
                    //else if (updatedPart instanceof OutsourcedPart) {
                    //OutsourcedPart outPart = (OutsourcedPart) updatedPart;
                    OutsourcedPart outPart = new OutsourcedPart();

                    rbInOutsourcedSelected(event);
                    outPart.setId(Integer.parseInt(AddPart_ID.getText()));
                    outPart.setName(partName);
                    outPart.setStock(partInventory);
                    outPart.setPrice(partPrice);
                    outPart.setMin(partMin);
                    outPart.setMax(partMax);

                    outPart.setCompanyName(AddPart_CompanyName.getText());
                    Inventory.updatePart(prtIndex, outPart);

                }
                if (Integer.parseInt(AddPart_Min.getText().trim())
                        > Integer.parseInt(AddPart_Max.getText().trim())) {
                    Alert minError = new Alert(Alert.AlertType.ERROR);
                    minError.setContentText("One or more fields contains an error.");
                    minError.setHeaderText("Min value cannot be greater than Max value, please correct.");
                    minError.setTitle("Error");
                    minError.showAndWait();
                    return;
                }

                backToMain(event);
            } catch (NumberFormatException e) {
                Alert adError = new Alert(Alert.AlertType.ERROR);
                adError.setContentText("One or more fields contains an error.");
                adError.setHeaderText("Please check :" + e.getMessage());
                adError.setTitle("Error");
                adError.showAndWait();

            }

        }

    }

    @FXML
    private void cancelModifyPart(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Cancel modifying ...");
        alert.setContentText("Are you sure you want to cancel modifying part: " + AddPart_Name.getText() + " ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            backToMain(event);
        }
    }

    private void backToMain(ActionEvent event) {

        Parent tableViewParent;
        try {
            tableViewParent = FXMLLoader.load(getClass().getResource("Main Screen.fxml"));

            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Inventory Management System");
            window.show();
        } catch (IOException ex) {
            Logger.getLogger(AddPartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void prtModify() {

        Part modPart = new Part() {
        };
        AddPart_Name.setText(modPart.getName());
    }

    private int modifyPartIndex() {
        return modifyPartIndex;
    }

    public void partTableUpdate() {
        modPartTableView.setItems(getAllParts());

    }

}
