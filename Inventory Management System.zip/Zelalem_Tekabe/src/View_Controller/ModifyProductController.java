/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.Inventory;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import Model.Product;
import Model.Part;
import static View_Controller.MainScreenController.productToModifyIndex;
import static Model.Inventory.getAllProducts;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import static Model.Inventory.getAllParts;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.stage.Modality;

/**
 * FXML Controller class
 *
 * @author zelal
 */
public class ModifyProductController implements Initializable {

    @FXML
    private Button modifyProduct_Delete;
    @FXML
    private Button saveProduct_Save;
    @FXML
    private Button modifyProduct_Cancel;

    private int productId;

    private int pdctIndex = productToModifyIndex();
    @FXML
    private TextField product_ID;
    @FXML
    private TextField product_Name;
    @FXML
    private TextField inventory;
    @FXML
    private TextField price;
    @FXML
    private TextField min;
    @FXML
    private TextField max;
    @FXML
    private Button modifyProductSearch;

    @FXML
    private TextField modifyProductSearchTxtBx;

    @FXML
    private ObservableList<Part> p = FXCollections.observableArrayList();

    @FXML
    private TableColumn<Part, Integer> modPartID;
    @FXML
    private TableColumn<Part, String> modPartName;
    @FXML
    private TableColumn<Part, Integer> modInvLevel;
    @FXML
    private TableColumn<Part, Double> modPrice;

    @FXML
    private TableColumn<Part, Integer> added_modPartID;
    @FXML
    private TableColumn<Part, String> added_modPartName;
    @FXML
    private TableColumn<Part, Integer> added_modInvLevel;
    @FXML
    private TableColumn<Part, Double> added_modprice;
    @FXML
    private TableView<Part> modPartTableView;
    @FXML
    private TableView<Part> modifyPartDeleteView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        Product prd = getAllProducts().get(pdctIndex);
        productId = getAllProducts().get(pdctIndex).getId();
        product_ID.setText(Integer.toString(productId));
        product_Name.setText(prd.getName());
        inventory.setText(Integer.toString(prd.getStock()));
        price.setText(Double.toString(prd.getPrice()));
        min.setText(Integer.toString(prd.getMin()));
        max.setText(Integer.toString(prd.getMax()));

        p = prd.getAssociatedParts();

        modPartID.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getId()).asObject());
        modPartName.setCellValueFactory(myData -> new SimpleStringProperty(myData.getValue().getName()));
        modInvLevel.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getStock()).asObject());
        modPrice.setCellValueFactory(myData -> new SimpleDoubleProperty(myData.getValue().getPrice()).asObject());

        added_modPartID.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getId()).asObject());
        added_modPartName.setCellValueFactory(myData -> new SimpleStringProperty(myData.getValue().getName()));
        added_modInvLevel.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getStock()).asObject());
        added_modprice.setCellValueFactory(myData -> new SimpleDoubleProperty(myData.getValue().getPrice()).asObject());

        partTableUpdate();
        partAddedTableView();
        // partAddedTableView();

    }

    @FXML
    private void addModifyProduct(ActionEvent event) throws Exception {
        try {
            Part modPart = modPartTableView.getSelectionModel().getSelectedItem();
            p.add(modPart);
            partAddedTableView();
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part.");
            Optional<ButtonType> result = alert.showAndWait();
        }

    }

    @FXML
    private void deleteModifyProduct(MouseEvent event) throws IOException {

        try {
            Part deleteModProduct = modifyPartDeleteView.getSelectionModel().getSelectedItem();
            Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDelete.setContentText("Are you sure you want to delete part : " + deleteModProduct.getName() + " ?");
            Optional<ButtonType> result = confirmDelete.showAndWait();
            if (result.get() == ButtonType.OK) {
                modifyPartDeleteView.getItems().remove(deleteModProduct);
                partAddedTableView();
            }

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part to delete.");
            Optional<ButtonType> result = alert.showAndWait();

        }

    }

    @FXML
    private void saveModifyProduct(ActionEvent event) {

        if (product_Name.getText().equals("") || product_Name.getText() == null
                || inventory.getText().equals("") || inventory.getText() == null
                || price.getText().equals("") || price.getText() == null
                || min.getText().equals("") || min.getText() == null
                || max.getText().equals("") || max.getText() == null) {
            Alert adError = new Alert(Alert.AlertType.ERROR);
            adError.setContentText("One or more fields have an error.");
            adError.setHeaderText("Please check your inputs!");
            adError.setTitle("Error");
            adError.showAndWait();

        } else {

            try {

                String pName = product_Name.getText();
                int pInventory = Integer.parseInt(inventory.getText());
                Double pPrice = Double.parseDouble(price.getText());
                int pMin = Integer.parseInt(min.getText());
                int pMax = Integer.parseInt(max.getText());

                Product updatedProduct = new Product();
                updatedProduct.setId(Integer.parseInt(product_ID.getText()));
                updatedProduct.setName(pName);
                updatedProduct.setStock(pInventory);
                updatedProduct.setPrice(pPrice);
                updatedProduct.setMin(pMin);
                updatedProduct.setMax(pMax);

                updatedProduct.setAssociatedParts(p);
                Inventory.updateProduct(pdctIndex, updatedProduct); 
                 if (Integer.parseInt(min.getText().trim())
                        > Integer.parseInt(max.getText().trim())) {
                    Alert minError = new Alert(Alert.AlertType.ERROR);
                    minError.setContentText("One or more fields contains an error.");
                    minError.setHeaderText("Min value cannot be greater than Max value, please correct.");
                    minError.setTitle("Error");
                    minError.showAndWait();
                    return;
                }
                
                backToMain(event);
            } catch (NumberFormatException e) {

                Alert adError = new Alert(Alert.AlertType.ERROR);
                adError.setContentText("One or more fields have an error.");
                adError.setHeaderText("Please check :" + e.getMessage());
                adError.setTitle("Error");
                adError.showAndWait();

            }
        }
    }

    @FXML
    private void cancelModifyProduct(ActionEvent event) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Cancel modifying ...");
        alert.setContentText("Are you sure you want to cancel modifying product: " + product_Name.getText() + " ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {

            backToMain(event);
        }

    }

    public void partTableUpdate() {
        modPartTableView.setItems(getAllParts());

    }

    public void partAddedTableView() {
        try {
            modifyPartDeleteView.setItems(p);
        } catch (Exception e) {
            Alert adError = new Alert(Alert.AlertType.ERROR);
            adError.setContentText("Error selecting a part.");
            adError.setHeaderText("Please check :" + e.getMessage());
            adError.setTitle("Error");
            adError.showAndWait();

        }
    }

    private void backToMain(ActionEvent event) {

        Parent tableViewParent;
        try {
            tableViewParent = FXMLLoader.load(getClass().getResource("Main Screen.fxml"));

            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Inventory Management System");
            window.show();
        } catch (IOException ex) {
            Logger.getLogger(AddPartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    void searchBtnModifyProduct(ActionEvent event) {

        try {
            if ((modifyProductSearchTxtBx.getText().trim().equals(""))
                    || modifyProductSearchTxtBx.getText() == null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.initModality(Modality.NONE);
                alert.setContentText("No part was found for part name : " + modifyProductSearchTxtBx.getText());
                Optional<ButtonType> result = alert.showAndWait();
            } else {

                String prtString = modifyProductSearchTxtBx.getText();
                int pIndex = -1;
                pIndex = Inventory.lookupPart(prtString);
                Part prt = Inventory.getAllParts().get(pIndex);
                ObservableList<Part> pList = FXCollections.observableArrayList();
                pList.add(prt);
                if (prt.getName().equalsIgnoreCase(prtString)) {
                    modPartTableView.setItems(pList);
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initModality(Modality.NONE);
                    alert.setContentText("No part was found for part name : " + modifyProductSearchTxtBx.getText());
                    Optional<ButtonType> result = alert.showAndWait();
                }

            }
        } catch (Exception e) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initModality(Modality.NONE);
            alert.setContentText("No part was found for part name : " + modifyProductSearchTxtBx.getText());
            Optional<ButtonType> result = alert.showAndWait();

        }
    }

    @FXML
    void searchClearedModify(MouseEvent event) {
        modifyProductSearchTxtBx.clear();
        partTableUpdate();

    }

}
