/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import static Model.Inventory.getAllParts;
import static Model.Inventory.getAllProducts;
import Model.Part;
import Model.Product;
import Model.Inventory;
import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Modality;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author zelal
 */
public class MainScreenController implements Initializable {

    @FXML
    private Label label;
    @FXML
    private Button Search_Parts;
    @FXML
    private Button Search_Products;
    @FXML
    private Button Add_Products;
    @FXML
    private Button Modify_Products;
    @FXML
    private Button Delete_Products;
    @FXML
    private Button Exit;

    @FXML
    private Button addParts;
    @FXML
    private Button modifyParts;
    @FXML
    private Button delPart;
    @FXML
    private TextField partSearchBox;
    @FXML
    private TextField productSearchBox;

    @FXML
    private TableView<Part> partsTableView;
    @FXML
    private TableView<Product> productsTableView;

    @FXML
    private TableColumn<Part, Integer> idParts;
    @FXML
    private TableColumn<Part, String> nameParts;
    @FXML
    private TableColumn<Part, Integer> stockParts;
    @FXML
    private TableColumn<Part, Double> priceParts;

    @FXML
    private TableColumn<Product, Integer> idProducts;
    @FXML
    private TableColumn<Product, String> nameProducts;
    @FXML
    private TableColumn<Product, Integer> stockProducts;
    @FXML
    private TableColumn<Product, Double> priceProducts;

    public ObservableList<Part> ptSearch = FXCollections.observableArrayList();
    public ObservableList<Product> prdSearch = FXCollections.observableArrayList();

    private static Part partToModify;
    private static Product productsToModify;
    private static int partModifyIndex;
    private static int productModifyIndex;

    public static Part getPartToModify() {
        return partToModify;
    }

    public static Product getProductsToModify() {
        return productsToModify;
    }

    public static int partsToModifyIndex() {
        return partModifyIndex;
    }

    public static int productToModifyIndex() {
        return productModifyIndex;
    }

    public static void setPartToModify(Part partToModify) {
        MainScreenController.partToModify = partToModify;
    }

    public static void setProductsToModify(Product productsToModify) {
        MainScreenController.productsToModify = productsToModify;
    }

    public MainScreenController() {

    }

    ;
    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // idParts.setCellValueFactory(cellData -> cellData.getValue().getId().asObject());     

        idParts.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        nameParts.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        stockParts.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getStock()).asObject());
        priceParts.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getPrice()).asObject());

        idProducts.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getId()).asObject());
        nameProducts.setCellValueFactory(cellData -> new SimpleStringProperty(cellData.getValue().getName()));
        stockProducts.setCellValueFactory(cellData -> new SimpleIntegerProperty(cellData.getValue().getStock()).asObject());
        priceProducts.setCellValueFactory(cellData -> new SimpleDoubleProperty(cellData.getValue().getPrice()).asObject());

        partsData();
        productsData();

    }

    //refresh part table view
    public void partsData() {
        partsTableView.setItems(getAllParts());
    }

    //refresh products table view
    public void productsData() {
        productsTableView.setItems(getAllProducts());
    }

    //open Add Part screen
    @FXML
    public void openAddPartScreen(ActionEvent event) throws IOException {

        Parent tableViewParent = FXMLLoader.load(getClass().getResource("Add Part.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setTitle("Adding a Part ...");
        window.show();
    }

    //open Modify Part screen
    @FXML
    public void openModifyPartScreen(ActionEvent event) throws IOException {

        try {
            partToModify = partsTableView.getSelectionModel().getSelectedItem();
            partModifyIndex = getAllParts().indexOf(partToModify);

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("Modify Part.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Modifying a Part ...");
            window.show();
        } catch (IOException e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part.");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }

    //open Add Product screen
    @FXML
    public void openAddProductScreen(ActionEvent event) throws IOException {

        Parent tableViewParent = FXMLLoader.load(getClass().getResource("Add Product.fxml"));
        Scene tableViewScene = new Scene(tableViewParent);
        Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
        window.setScene(tableViewScene);
        window.setTitle("Adding a Product ...");
        window.show();

    }

    //open Modify Product screen
    @FXML
    public void openModifyProductScreen(ActionEvent event) throws IOException {

        try {

            productsToModify = productsTableView.getSelectionModel().getSelectedItem();
            productModifyIndex = getAllProducts().indexOf(productsToModify);

            Parent tableViewParent = FXMLLoader.load(getClass().getResource("Modify Product.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Modify a Product ...");
            window.show();
        } catch (IOException e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a product.");
            Optional<ButtonType> result = alert.showAndWait();

        }
    }

    @FXML
    public void handleExit(ActionEvent e) {

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.APPLICATION_MODAL);
        alert.getDialogPane().backgroundProperty();
        alert.setContentText("Are you sure you want to exit the system?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            System.exit(0);
        }
    }

    @FXML
    private void deletePart(ActionEvent event) {

        try {
        
        Part delPart = partsTableView.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Deleting a Part ...");
        alert.setContentText("Are you sure you want to delete  Part: " + delPart.getName() + " (Part ID: " + delPart.getId() + ")" + " ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            partsTableView.getItems().remove(delPart);
            partsData();
        }
        }
        catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part.");
            Optional<ButtonType> result = alert.showAndWait();
                
                } 
                
        
    }

    ;
    


    @FXML
    private void deleteProduct(MouseEvent event) {

        try {
        Product delProduct = productsTableView.getSelectionModel().getSelectedItem();

        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.initModality(Modality.NONE);
        alert.setTitle("Deleting a Product ...");
        alert.setContentText("Are you sure you want to delete  Product: " + delProduct.getName() + " (Part ID: " + delProduct.getId() + ")" + " ?");
        Optional<ButtonType> result = alert.showAndWait();

        if (result.get() == ButtonType.OK) {
            productsTableView.getItems().remove(delProduct);
            productsData();

        }
        
        
         }
        catch (Exception e) {
                 Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a product.");
            Optional<ButtonType> result = alert.showAndWait();
                
                } 

    }

    private void modifyPart(ActionEvent event) throws IOException {
        partToModify = partsTableView.getSelectionModel().getSelectedItem();
        setPartToModify(partToModify);
        openModifyPartScreen(event);
    }

    private void modifyProduct(ActionEvent event) throws IOException {
        productsToModify = productsTableView.getSelectionModel().getSelectedItem();
        setProductsToModify(productsToModify);
        openModifyProductScreen(event);

    }

    @FXML
    void searchPart(ActionEvent event) throws IOException {

        try {
            if ((partSearchBox.getText().trim().equals(""))
                    || partSearchBox.getText() == null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.initModality(Modality.NONE);
                //alert.setTitle("No part found");
                alert.setContentText("No part was found for part name : " + partSearchBox.getText());
                Optional<ButtonType> result = alert.showAndWait();
            } else {

                String prtString = partSearchBox.getText();
                int pIndex = -1;
                pIndex = Inventory.lookupPart(prtString);
                Part prt = Inventory.getAllParts().get(pIndex);
                ObservableList<Part> pList = FXCollections.observableArrayList();
                pList.add(prt);
                if (prt.getName().equalsIgnoreCase(prtString)) {
                    partsTableView.setItems(pList);
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initModality(Modality.NONE);
                    //alert.setTitle("No part found");
                    alert.setContentText("No part was found for part name : " + partSearchBox.getText());
                    Optional<ButtonType> result = alert.showAndWait();
                }

            }
        } catch (Exception e) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initModality(Modality.NONE);
            alert.setContentText("No part was found for part name : " + partSearchBox.getText());
            Optional<ButtonType> result = alert.showAndWait();

        }
    }

    @FXML
    private void searchProduct(ActionEvent event) throws IOException {

        try {
            if ((productSearchBox.getText().trim().equals(""))
                    || productSearchBox.getText() == null) {

                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.initModality(Modality.NONE);
                //alert.setTitle("No product found");
                alert.setContentText("No product was forund for part name :" + productSearchBox.getText());
                Optional<ButtonType> result = alert.showAndWait();
            } else {

                String pdctString = productSearchBox.getText().trim();
                int prIndex = -1;
                prIndex = Inventory.lookupProduct(pdctString);
                Product prdct = Inventory.getAllProducts().get(prIndex);
                ObservableList<Product> prList = FXCollections.observableArrayList();
                prList.add(prdct);
                if (prdct.getName().equalsIgnoreCase(pdctString)) {
                    productsTableView.setItems(prList);
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initModality(Modality.NONE);
                    alert.setContentText("No product was found for product name : " + productSearchBox.getText());
                    Optional<ButtonType> result = alert.showAndWait();
                }
            }
        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initModality(Modality.NONE);
            alert.setContentText("No product was found for product name :"+productSearchBox.getText());
            Optional<ButtonType> result = alert.showAndWait();
        }
    }

    ;
    
    @FXML
    void partCleared(MouseEvent event) {
        partSearchBox.clear();
        partsData();

    }

    @FXML
    void productCleared(MouseEvent event) {
        productSearchBox.clear();
        productsData();
    }

}
