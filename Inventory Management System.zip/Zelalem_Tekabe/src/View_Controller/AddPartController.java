/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.input.MouseEvent;
import javafx.scene.text.Text;
import javafx.stage.Stage;

import Model.InhousePart;
import Model.Inventory;
import Model.OutsourcedPart;
import Model.Part;
import java.util.Optional;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.text.Font;

/**
 * FXML Controller class
 *
 * @author zelal
 */
public class AddPartController implements Initializable {

    //radio buttons
    private ToggleGroup rbToggleGroup;
    @FXML
    private RadioButton InHouse;
    @FXML
    private RadioButton Outsourced;
    @FXML
    private Text CompanyNameOrID;

    @FXML
    private TextField AddPart_ID;
    @FXML
    private TextField AddPart_Name;
    @FXML
    private TextField AddPart_Inventory;
    @FXML
    private TextField AddPart_PriceCost;
    @FXML
    private TextField AddPart_Min;
    @FXML
    private TextField AddPart_Max;

    @FXML
    private TextField MachineID_or_Name;

    @FXML
    public void rbChangedAddPart() {
        if (this.rbToggleGroup.getSelectedToggle().equals(this.Outsourced)) {
            this.CompanyNameOrID.setText("Company Name :");
        }

        if (this.rbToggleGroup.getSelectedToggle().equals(this.InHouse)) {
            this.CompanyNameOrID.setText("Machine ID :");
        }

    }

    /**
     * Initializes the controller class.
     *
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //Radio button configuration       
        rbToggleGroup = new ToggleGroup();
        this.InHouse.setToggleGroup(rbToggleGroup);
        this.Outsourced.setToggleGroup(rbToggleGroup);

        this.Outsourced.setSelected(true);
        rbChangedAddPart();

        //Parts ID
        int partId = Inventory.partsId();
        AddPart_ID.setText(Integer.toString(partId));

    }

    private void backToMain(ActionEvent event) {
        Parent tableViewParent;
        try {
            tableViewParent = FXMLLoader.load(getClass().getResource("Main Screen.fxml"));

            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Inventory Management System");
            window.show();
        } catch (IOException ex) {
            Logger.getLogger(AddPartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void cancelPart(ActionEvent event) {

        Font ft = Font.font(null, 20);
        Text partCancelled = new Text(AddPart_Name.getText());
        partCancelled.fontProperty().getValue().equals(ft);
        partCancelled.setStyle("-fx-font-weight: bold");

        String txt = partCancelled.textProperty().getValue();
        boolean test = txt.trim().isEmpty();

        if (test == true) {
            backToMain(event);
        } else {

            Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
            cancelAlert.setContentText("Are you sure you want to cancel adding Part: " + partCancelled.getText() + " ?");
            Optional<ButtonType> result = cancelAlert.showAndWait();
            if (result.get() == ButtonType.OK) {
                backToMain(event);
            }
        }

    }

    @FXML
    private void savePart(ActionEvent event) throws NumberFormatException {
        try {

     
        if (AddPart_Name.getText().equals("") || AddPart_Min.getText().equalsIgnoreCase("") || AddPart_Max.getText().equalsIgnoreCase("") ) {
             Alert minError = new Alert(Alert.AlertType.ERROR);
            minError.setContentText("One or more fields contain a blank field, please correct.");
            minError.setHeaderText("Blank fields.");
            minError.setTitle("Error");
            minError.showAndWait();
            return;
        }
        
        if (AddPart_PriceCost.getText().equals("") || AddPart_PriceCost.getText() == null) {
            AddPart_PriceCost.setText("0");
        }

        if (AddPart_Inventory.getText().equals("") || AddPart_Inventory.getText() == null) {
            AddPart_Inventory.setText("0");
        }
        if (Integer.parseInt(AddPart_Min.getText().trim())
                > Integer.parseInt(AddPart_Max.getText().trim())) {
            Alert minError = new Alert(Alert.AlertType.ERROR);
            minError.setContentText("One or more fields contains an error.");
            minError.setHeaderText("Min value cannot be greater than Max value, please correct.");
            minError.setTitle("Error");
            minError.showAndWait();
        } else {
            //Inhouse part selected
            if (this.rbToggleGroup.getSelectedToggle().equals(this.InHouse)) {

                try {
//                    if (Integer.parseInt(MachineID_or_Name.getText().trim()) != integer){//                     
//                    }
                   
                    InhousePart inHousePart = new InhousePart();
                    inHousePart.setMachineId(Integer.parseInt(MachineID_or_Name.getText().trim()));//
                    inHousePart.setId(Integer.parseInt(AddPart_ID.getText().trim()));
                    inHousePart.setName(AddPart_Name.getText().trim());
                    inHousePart.setPrice(Double.parseDouble(AddPart_PriceCost.getText().trim()));
                    inHousePart.setStock(Integer.parseInt(AddPart_Inventory.getText().trim()));
                    inHousePart.setMin(Integer.parseInt(AddPart_Min.getText().trim()));
                    inHousePart.setMax(Integer.parseInt(AddPart_Max.getText().trim()));
                    Inventory.addPart(inHousePart);
                    backToMain(event);
                } catch (NumberFormatException e) {
                    Alert adError = new Alert(Alert.AlertType.ERROR);
                    adError.setContentText("One or more fields contains an error.");
                    adError.setHeaderText("Please check :" + e.getMessage());
                    adError.setTitle("Error");
                    adError.showAndWait();
                }

            } 
            else if (this.rbToggleGroup.getSelectedToggle().equals(this.Outsourced)) {
                try {
                    {

                        OutsourcedPart outPart = new OutsourcedPart();
                        outPart.setCompanyName(MachineID_or_Name.getText().trim());//                        
                        outPart.setId(Integer.parseInt(AddPart_ID.getText().trim()));
                        outPart.setName(AddPart_Name.getText().trim());
                        outPart.setPrice(Double.parseDouble(AddPart_PriceCost.getText().trim()));
                        outPart.setStock(Integer.parseInt(AddPart_Inventory.getText().trim()));
                        outPart.setMin(Integer.parseInt(AddPart_Min.getText().trim()));
                        outPart.setMax(Integer.parseInt(AddPart_Max.getText().trim()));
                        Inventory.addPart(outPart);
                        backToMain(event);

                    }

                } catch (NumberFormatException e) {
                    Alert adError = new Alert(Alert.AlertType.ERROR);
                    adError.setContentText("One or more fields contains an error.");
                    adError.setHeaderText("Please check :" + e.getMessage());
                    adError.setTitle("Error");
                    adError.showAndWait();

                }
            }
        }}
        
        //catch here
        catch (NumberFormatException e){ 
                 Alert adError = new Alert(Alert.AlertType.ERROR);
                    adError.setContentText("One or more fields contains an error.");
                    adError.setHeaderText("Please check :" + e.getMessage());
                    adError.setTitle("Error");
                    adError.showAndWait();
                }
        }
    }

