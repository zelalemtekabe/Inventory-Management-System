/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.Inventory;
import static Model.Inventory.getAllParts;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import Model.Part;
import Model.Product;
import java.util.Optional;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Modality;

/**
 * FXML Controller class
 *
 * @author zelal
 */
public class AddProductController implements Initializable {

    @FXML
    private Button addProduct_Delete;
    @FXML
    private Button addProduct_Save;
    @FXML
    private Button addProduct_Cancel;
    @FXML
    private TextField AddProduct_ID;
    @FXML
    private TextField AddProduct_Name;
    @FXML
    private TextField AddProduct_Stock;
    @FXML
    private TextField AddProduct_Price;
    @FXML
    private TextField AddProduct_Min;
    @FXML
    private TextField AddProduct_Max;

    @FXML
    private TextField addPrdctSearchTxtBx;

    @FXML
    private TableColumn<Part, Integer> modPartID;
    @FXML
    private TableColumn<Part, String> modPartName;
    @FXML
    private TableColumn<Part, Integer> modInvLevel;
    @FXML
    private TableColumn<Part, Double> modPrice;

    @FXML
    private TableColumn<Part, Integer> added_modPartID;
    @FXML
    private TableColumn<Part, String> added_modPartName;
    @FXML
    private TableColumn<Part, Integer> added_modInvLevel;
    @FXML
    private TableColumn<Part, Double> added_modprice;

    private ObservableList<Part> prts = FXCollections.observableArrayList();

    @FXML
    private TableView<Part> addProductTableView;
    @FXML
    private TableView<Part> addedAddProductTableView;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {

        try {
            modPartID.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getId()).asObject());
            modPartName.setCellValueFactory(myData -> new SimpleStringProperty(myData.getValue().getName()));
            modInvLevel.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getStock()).asObject());
            modPrice.setCellValueFactory(myData -> new SimpleDoubleProperty(myData.getValue().getPrice()).asObject());

            added_modPartID.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getId()).asObject());
            added_modPartName.setCellValueFactory(myData -> new SimpleStringProperty(myData.getValue().getName()));
            added_modInvLevel.setCellValueFactory(myData -> new SimpleIntegerProperty(myData.getValue().getStock()).asObject());
            added_modprice.setCellValueFactory(myData -> new SimpleDoubleProperty(myData.getValue().getPrice()).asObject());

            //Parts ID
            int prdctId = Inventory.productsId();
            AddProduct_ID.setText(Integer.toString(prdctId));

            addPartTable();
            addedAddPartTable();
        } catch (Exception e) {
                Alert adError = new Alert(Alert.AlertType.ERROR);
                adError.setContentText("One or more fields contains an error.");
                adError.setHeaderText("Please check :" + e.getMessage());
                adError.setTitle("Error");
                adError.showAndWait();
        }
    }

    private void backToMain(ActionEvent event) {

        Parent tableViewParent;
        try {
            tableViewParent = FXMLLoader.load(getClass().getResource("Main Screen.fxml"));

            Scene tableViewScene = new Scene(tableViewParent);
            Stage window = (Stage) ((Node) event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.setTitle("Inventory Management System");
            window.show();
        } catch (IOException ex) {
            Logger.getLogger(AddPartController.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @FXML
    private void saveProduct(ActionEvent event) {

        if (AddProduct_Min.getText().trim().equalsIgnoreCase("")
                || AddProduct_Max.getText().trim().equalsIgnoreCase("")
                || AddProduct_Name.getText().trim().equalsIgnoreCase("")) {
            Alert minError = new Alert(Alert.AlertType.ERROR);
            minError.setContentText("One or more fields contain a blank field, please correct.");
            minError.setHeaderText("Blank fields.");
            minError.setTitle("Error");
            minError.showAndWait();
            return;
        }

        if (Integer.parseInt(AddProduct_Min.getText().trim())
                > Integer.parseInt(AddProduct_Max.getText().trim())) {
            Alert minError = new Alert(Alert.AlertType.ERROR);
            minError.setContentText("One or more fields contains an error.");
            minError.setHeaderText("Min value cannot be greater than Max value, please correct.");
            minError.setTitle("Error");
            minError.showAndWait();

        } else {
            try {

                Product prod = new Product();

                prod.setId(Integer.parseInt(AddProduct_ID.getText().trim())); //ISSUE HERE
                prod.setName(AddProduct_Name.getText().trim());
                prod.setStock(Integer.parseInt(AddProduct_Stock.getText().trim()));
                prod.setPrice(Double.parseDouble(AddProduct_Price.getText().trim()));
                prod.setMin(Integer.parseInt(AddProduct_Min.getText().trim()));
                prod.setMax(Integer.parseInt(AddProduct_Max.getText().trim()));

                Inventory.addProduct(prod);

                for (Part pr : prts) {
                    prod.addAssociatedPart(pr);

                }

                backToMain(event);

            } catch (NumberFormatException e) {
                Alert adError = new Alert(Alert.AlertType.ERROR);
                adError.setContentText("One or more fields contain an error.");
                //adError.setHeaderText("Please check your inputs!");
                adError.setHeaderText("Please check :" + e.getMessage());
                adError.setTitle("Error");
                adError.showAndWait();
            }
        }
    }

    @FXML
    private void cancelProduct(ActionEvent event) {

        //Font fnt = Font.font("", FontWeight.BOLD, FontPosture.ITALIC, 20);
        Font ft = Font.font(null, 20);

        Text productCancelled = new Text(AddProduct_Name.getText());
        productCancelled.fontProperty().getValue().equals(ft);
        productCancelled.setStyle("-fx-font-weight: bold");

        String txt = productCancelled.textProperty().getValue();
        boolean test = txt.trim().isEmpty();

        if (test == true) {
            backToMain(event);
        } else {

            Alert cancelAlert = new Alert(Alert.AlertType.CONFIRMATION);
            cancelAlert.setContentText("Are you sure you want to cancel adding product : " + productCancelled.getText() + " ?");
            Optional<ButtonType> result = cancelAlert.showAndWait();
            if (result.get() == ButtonType.OK) {
                backToMain(event);
            }

        }
    }

    @FXML
    private void addPartAddedTableView(ActionEvent event) throws Exception  {

        try {
            Part addedPart = addProductTableView.getSelectionModel().getSelectedItem();
            prts.add(addedPart);
            addedAddPartTable(); 
        } catch (Exception e) {

            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part.");
            Optional<ButtonType> result = alert.showAndWait();
        }
    }

    @FXML
    public void addPartTable() {
        addProductTableView.setItems(getAllParts());

    }

    @FXML
    private void addedAddPartTable()  {
        try {
            addedAddProductTableView.setItems(prts);

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part.");
            Optional<ButtonType> result = alert.showAndWait();

        }
    }

    @FXML
    private void deleteProduct(ActionEvent event) {

        try {
            Part deletePart = addedAddProductTableView.getSelectionModel().getSelectedItem();

            Alert confirmDelete = new Alert(Alert.AlertType.CONFIRMATION);
            confirmDelete.setContentText("Are you sure you want to delete part : " + deletePart.getName() + " ?");
            Optional<ButtonType> result = confirmDelete.showAndWait();
            if (result.get() == ButtonType.OK) {
                //prts.remove(deletePart);
                addedAddProductTableView.getItems().remove(deletePart);
                addedAddPartTable();

            }

        } catch (Exception e) {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.initModality(Modality.NONE);
            alert.setTitle("Error...");
            alert.setContentText("Error selecting a part to delete.");
            Optional<ButtonType> result = alert.showAndWait();

        }
    }

    @FXML
    void searchBtnAddProduct(ActionEvent event) {

        try {
            if ((addPrdctSearchTxtBx.getText().trim().equals(""))
                    || addPrdctSearchTxtBx.getText() == null) {
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.initModality(Modality.NONE);
                //alert.setTitle("No part found");
                alert.setContentText("No part was found for part name : " + addPrdctSearchTxtBx.getText());
                Optional<ButtonType> result = alert.showAndWait();
            } else {

                String prtString = addPrdctSearchTxtBx.getText();
                int pIndex = -1;
                pIndex = Inventory.lookupPart(prtString);
                Part prt = Inventory.getAllParts().get(pIndex);
                ObservableList<Part> pList = FXCollections.observableArrayList();
                pList.add(prt);
                if (prt.getName().equalsIgnoreCase(prtString)) {
                    addProductTableView.setItems(pList);
                } else {
                    Alert alert = new Alert(Alert.AlertType.INFORMATION);
                    alert.initModality(Modality.NONE);
                    //alert.setTitle("No part found");
                    alert.setContentText("No part was found for part name : " + addPrdctSearchTxtBx.getText());
                    Optional<ButtonType> result = alert.showAndWait();
                }

            }
        } catch (Exception e) {

            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.initModality(Modality.NONE);
            alert.setContentText("No part was found for part name : " + addPrdctSearchTxtBx.getText());
            Optional<ButtonType> result = alert.showAndWait();

        }

    }

    @FXML
    void searchCleared(MouseEvent event) {
        addPrdctSearchTxtBx.clear();
        addPartTable();

    }

}
