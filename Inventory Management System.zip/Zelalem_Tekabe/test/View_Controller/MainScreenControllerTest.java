/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package View_Controller;

import Model.InhousePart;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author zelal
 */
public class MainScreenControllerTest {
    
    public MainScreenControllerTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of initialize method, of class MainScreenController.
     */
    @Test
    public void testInitialize() {
        System.out.println("initialize");
        URL url = null;
        ResourceBundle rb = null;
        MainScreenController instance = new MainScreenController();
        instance.initialize(url, rb);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of getPart method, of class MainScreenController.
     */
    @Test
    public void testGetPart() {
        System.out.println("getPart");
        MainScreenController instance = new MainScreenController();
        ObservableList<InhousePart> expResult = null;
        ObservableList<InhousePart> result = instance.getPart();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of openAddPartScreen method, of class MainScreenController.
     */
    @Test
    public void testOpenAddPartScreen() throws Exception {
        System.out.println("openAddPartScreen");
        ActionEvent event = null;
        MainScreenController instance = new MainScreenController();
        instance.openAddPartScreen(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of openModifyPartScreen method, of class MainScreenController.
     */
    @Test
    public void testOpenModifyPartScreen() throws Exception {
        System.out.println("openModifyPartScreen");
        ActionEvent event = null;
        MainScreenController instance = new MainScreenController();
        instance.openModifyPartScreen(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of openAddProductScreen method, of class MainScreenController.
     */
    @Test
    public void testOpenAddProductScreen() throws Exception {
        System.out.println("openAddProductScreen");
        ActionEvent event = null;
        MainScreenController instance = new MainScreenController();
        instance.openAddProductScreen(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of openModifyProductScreen method, of class MainScreenController.
     */
    @Test
    public void testOpenModifyProductScreen() throws Exception {
        System.out.println("openModifyProductScreen");
        ActionEvent event = null;
        MainScreenController instance = new MainScreenController();
        instance.openModifyProductScreen(event);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of handleExit method, of class MainScreenController.
     */
    @Test
    public void testHandleExit() {
        System.out.println("handleExit");
        ActionEvent e = null;
        MainScreenController instance = new MainScreenController();
        instance.handleExit(e);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
